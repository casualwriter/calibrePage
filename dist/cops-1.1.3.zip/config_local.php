<?php
    if (!isset($config))
        $config = array();
  
    /*
     * The directory containing calibre's metadata.db file, with sub-directories
     * containing all the formats.
     * BEWARE : it has to end with a /
     */
    $config['calibre_directory'] = '../calibre/';
        
    /*
     * Catalog's title
     */
    $config['cops_title_default'] = "My Calibre Library";
    
    /*
     * use URL rewriting for downloading of ebook in HTML catalog
     * See README for more information
     *  1 : enable
     *  0 : disable
     */
    $config['cops_use_url_rewriting'] = "1";
		file_put_contents( "access.log", date("Y-m-d H:i:s")."@".getenv('REMOTE_ADDR').": ". $_SERVER['REQUEST_URI']."\n", FILE_APPEND );